# X86 Склад Android v1.5

Android WebView wrapper for https://x86.kz/stock/.

Current additions:
- native Back gesture handling for SPA screens and product cards;
- double-Back exit protection on Home;
- quick SCAN action integrated into the bottom navigation;
- camera access for barcode scanning;
- PDF/blob downloads saved to Downloads/X86;
- downloaded PDF opens automatically in the default PDF viewer;
- Release signing configured through environment variables, with no private signing key stored in the project.

Release signing variables:
- X86_KEYSTORE_PATH
- X86_KEYSTORE_PASSWORD

Key alias is fixed to `x86-release`.
