package kz.x86.stock;

import android.Manifest;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.Window;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.window.OnBackInvokedDispatcher;

public class MainActivity extends Activity {
    private static final String START_URL = "https://x86.kz/stock/";
    private static final int REQ_CAMERA = 1001;
    private static final int REQ_FILE = 1002;
    private static final long EXIT_CONFIRM_MS = 2000L;

    /*
     * X86 Stock is mostly a single-page interface. Some screens (for example
     * the product card shown as a panel) do not add an entry to WebView's
     * navigation history. Android therefore cannot know that there is a
     * screen to close. Before touching native history we ask the page to close
     * the visible dialog/panel itself.
     */
    private static final String PAGE_BACK_JS =
            "(function(){" +
            "function vis(e){if(!e)return false;var s=getComputedStyle(e),r=e.getBoundingClientRect();" +
            "return s.display!=='none'&&s.visibility!=='hidden'&&parseFloat(s.opacity||'1')>0&&r.width>0&&r.height>0;}" +
            "function click(e){try{e.click();return true;}catch(x){return false;}}" +
            "var dialogs=[].slice.call(document.querySelectorAll('[role=\\\"dialog\\\"],dialog[open],.modal.show,.modal.active,.modal.open,.drawer.open,.drawer.active,.sheet.open,.sheet.active,.popup.open,.popup.active,.overlay.open,.overlay.active'));" +
            "for(var i=dialogs.length-1;i>=0;i--){var d=dialogs[i];if(!vis(d))continue;" +
            "var c=d.querySelector('[data-bs-dismiss=\\\"modal\\\"],[data-dismiss=\\\"modal\\\"],[data-close],button[aria-label*=\\\"close\\\" i],button[aria-label*=\\\"закры\\\" i],.modal-close,.drawer-close,.sheet-close,.popup-close,.close');" +
            "if(c&&vis(c))return click(c);" +
            "var a=[].slice.call(d.querySelectorAll('button,a,[role=button],span,div'));" +
            "for(var j=a.length-1;j>=0;j--){var t=(a[j].textContent||'').trim();if((t==='×'||t==='✕'||t==='✖'||t==='x'||t==='X')&&vis(a[j]))return click(a[j]);}" +
            "}" +
            "var all=[].slice.call(document.querySelectorAll('button,a,[role=button],span,div'));" +
            "for(var k=all.length-1;k>=0;k--){var e=all[k];if(!vis(e))continue;var t=(e.textContent||'').trim();" +
            "if(!(t==='×'||t==='✕'||t==='✖'||t==='x'||t==='X'))continue;var r=e.getBoundingClientRect();" +
            "if(r.left>window.innerWidth*0.55&&r.top<window.innerHeight*0.35)return click(e);}" +
            "var b=document.querySelector('button[aria-label*=\\\"back\\\" i],a[aria-label*=\\\"back\\\" i],button[aria-label*=\\\"назад\\\" i],a[aria-label*=\\\"назад\\\" i],[data-back],.back-button,.btn-back');" +
            "if(b&&vis(b))return click(b);" +
            "return false;" +
            "})()";


    private static final String HOME_BACK_JS =
            "(function(){" +
            "function vis(e){if(!e)return false;var s=getComputedStyle(e),r=e.getBoundingClientRect();return s.display!=='none'&&s.visibility!=='hidden'&&r.width>0&&r.height>0;}" +
            "function active(e){var n=e;for(var z=0;z<4&&n;z++,n=n.parentElement){" +
            "var c=(' '+String(n.className||'')+' ').toLowerCase();" +
            "if(c.indexOf(' active ')>=0||c.indexOf(' current ')>=0||c.indexOf(' selected ')>=0)return true;" +
            "var ac=n.getAttribute&&n.getAttribute('aria-current');if(ac&&ac!=='false')return true;" +
            "if(n.getAttribute&&n.getAttribute('aria-selected')==='true')return true;" +
            "if(n.getAttribute&&n.getAttribute('data-active')==='true')return true;}return false;}" +
            "var a=[].slice.call(document.querySelectorAll('a,button,[role=button],[data-page],[data-tab],[data-section]'));" +
            "var home=null;for(var i=0;i<a.length;i++){var e=a[i];if(!vis(e))continue;" +
            "var t=((e.textContent||'')+' '+(e.getAttribute('aria-label')||'')).trim().toLowerCase();" +
            "var h=(e.getAttribute('href')||'').toLowerCase();" +
            "var d=((e.getAttribute('data-page')||'')+' '+(e.getAttribute('data-tab')||'')+' '+(e.getAttribute('data-section')||'')).toLowerCase();" +
            "if(t.indexOf('главная')!==-1||h.indexOf('home')!==-1||d.indexOf('home')!==-1){home=e;break;}}" +
            "if(!home)return 'unknown';if(active(home))return 'home';" +
            "try{home.click();return 'navigated';}catch(x){return 'unknown';}" +
            "})()";

    private WebView webView;
    private PermissionRequest pendingPermissionRequest;
    private ValueCallback<Uri[]> fileCallback;
    private String currentUrl = START_URL;
    private long lastBackAt = 0L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(248, 250, 252));
        window.setNavigationBarColor(Color.WHITE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            );
        }

        webView = new WebView(this);
        setContentView(webView);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    OnBackInvokedDispatcher.PRIORITY_DEFAULT,
                    this::handleBack
            );
        }

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        }

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            cookies.setAcceptThirdPartyCookies(webView, true);
        }

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) return false;
                return openExternal(uri);
            }

            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                Uri uri = Uri.parse(url);
                String scheme = uri.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) return false;
                return openExternal(uri);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                currentUrl = url;
                lastBackAt = 0L;
            }

            @Override
            public void doUpdateVisitedHistory(WebView view, String url, boolean isReload) {
                super.doUpdateVisitedHistory(view, url, isReload);
                if (url != null && !url.isEmpty()) currentUrl = url;
                lastBackAt = 0L;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> {
                    boolean wantsCamera = false;
                    for (String r : request.getResources()) {
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) {
                            wantsCamera = true;
                            break;
                        }
                    }
                    if (!wantsCamera) {
                        request.deny();
                        return;
                    }
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
                            checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        request.grant(request.getResources());
                    } else {
                        pendingPermissionRequest = request;
                        requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
                    }
                });
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback,
                                             FileChooserParams fileChooserParams) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = filePathCallback;
                Intent intent = fileChooserParams.createIntent();
                try {
                    startActivityForResult(intent, REQ_FILE);
                    return true;
                } catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    Toast.makeText(MainActivity.this, "Не удалось открыть выбор файла", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });

        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition,
                                        String mimetype, long contentLength) {
                try {
                    DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                    request.setMimeType(mimetype);
                    request.addRequestHeader("User-Agent", userAgent);
                    String cookie = CookieManager.getInstance().getCookie(url);
                    if (cookie != null) request.addRequestHeader("Cookie", cookie);
                    String name = URLUtil.guessFileName(url, contentDisposition, mimetype);
                    request.setTitle(name);
                    request.setDescription("X86 Склад");
                    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
                    DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                    dm.enqueue(request);
                    Toast.makeText(MainActivity.this, "Файл скачивается", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    openExternal(Uri.parse(url));
                }
            }
        });

        if (savedInstanceState == null) {
            webView.loadUrl(START_URL);
        } else {
            webView.restoreState(savedInstanceState);
            String restoredUrl = webView.getUrl();
            if (restoredUrl != null && !restoredUrl.isEmpty()) currentUrl = restoredUrl;
        }
    }

    private boolean openExternal(Uri uri) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private String normalizeUrl(String url) {
        if (url == null) return "";
        return url.endsWith("/") ? url.substring(0, url.length() - 1) : url;
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    private void handleBack() {
        if (webView == null) {
            confirmExit();
            return;
        }

        // First close an in-page card/dialog. Product cards in X86 Stock do not
        // create browser history, so native Back must close them via the page.
        webView.evaluateJavascript(PAGE_BACK_JS, result -> runOnUiThread(() -> {
            if ("true".equals(result)) {
                lastBackAt = 0L;
                return;
            }

            if (webView.canGoBack()) {
                lastBackAt = 0L;
                webView.goBack();
                return;
            }

            backFallback();
        }));
    }

    private void backFallback() {
        String url = webView != null ? webView.getUrl() : currentUrl;
        String current = normalizeUrl(url);
        String start = normalizeUrl(START_URL);

        // A real URL outside the stock root goes back to the stock home first.
        if (!current.isEmpty() && !current.equals(start)) {
            lastBackAt = 0L;
            webView.loadUrl(START_URL);
            return;
        }

        // The bottom tabs are SPA state and usually keep the same /stock/ URL.
        // If a non-home tab is active, Back switches to "Главная". If
        // "Главная" is already active, enable double-Back exit protection.
        webView.evaluateJavascript(HOME_BACK_JS, result -> runOnUiThread(() -> {
            if ("\"home\"".equals(result)) {
                confirmExit();
                return;
            }

            if ("\"navigated\"".equals(result)) {
                lastBackAt = 0L;
                return;
            }

            // If markup ever changes, loading the stock root is the safe fallback.
            // The next Back on the actual home screen will show the exit prompt.
            lastBackAt = 0L;
            webView.loadUrl(START_URL);
        }));
    }

    private void confirmExit() {
        long now = System.currentTimeMillis();
        if (now - lastBackAt <= EXIT_CONFIRM_MS) {
            lastBackAt = 0L;
            finishAndRemoveTask();
            return;
        }

        lastBackAt = now;
        Toast.makeText(this, "Нажмите ещё раз «Назад», чтобы выйти", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onBackPressed() {
        handleBack();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_CAMERA && pendingPermissionRequest != null) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                pendingPermissionRequest.grant(pendingPermissionRequest.getResources());
            } else {
                pendingPermissionRequest.deny();
                Toast.makeText(this, "Камера нужна для сканирования этикеток", Toast.LENGTH_LONG).show();
            }
            pendingPermissionRequest = null;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE && fileCallback != null) {
            Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }
}
